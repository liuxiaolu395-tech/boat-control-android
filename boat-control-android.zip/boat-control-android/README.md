# boat-control-android

Minimal Kotlin Android sample for WiFi boat control + FPV video.

Features:
- TCP / UDP / WebSocket clients (simple wrappers)
- ExoPlayer RTSP video fragment
- Buttons with "press-and-hold" send loop
- GitHub Actions workflow to build assembleDebug and upload APK artifact

License: MIT
